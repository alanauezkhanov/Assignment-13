// app.js
Vue.component('timeline', {
    props: ['events'],
    template: `
      <div class="timeline">
        <div v-for="event in sortedEvents" class="event" @click="toggleDescription(event)">
          <div class="event-header">
            <h3>{{ event.title }}</h3>
            <span class="event-date">{{ event.date }}</span>
          </div>
          <div v-if="event.showDescription" class="event-description">
            <p>{{ event.description }}</p>
          </div>
        </div>
      </div>
    `,
    computed: {
      sortedEvents() {
        // Sort events by date in ascending order
        return this.events.sort((a, b) => new Date(a.date) - new Date(b.date));
      }
    },
    methods: {
      toggleDescription(event) {
        event.showDescription = !event.showDescription;
      }
    }
  });

  new Vue({
    el: '#app',
    data: {
      events: [
        {
          title: 'Conference on Artificial Intelligence',
          date: '2023-05-15',
          description: 'A conference showcasing the latest advancements in artificial intelligence technologies and applications.',
          showDescription: false
        },
        {
          title: 'Product Launch: Smartphone X',
          date: '2023-07-01',
          description: 'The launch event for Smartphone X, a highly anticipated device with innovative features and cutting-edge technology.',
          showDescription: false
        },
        {
          title: 'Charity Gala Dinner',
          date: '2023-09-10',
          description: 'An elegant gala dinner to raise funds for a charitable cause and support local community projects.',
          showDescription: false
        },
        {
          title: 'Workshop: Web Development Basics',
          date: '2023-06-20',
          description: 'A hands-on workshop for beginners to learn the fundamentals of web development, including HTML, CSS, and JavaScript.',
          showDescription: false
        },
        {
          title: 'Music Festival: Summer Vibes',
          date: '2023-08-05',
          description: 'A vibrant music festival featuring popular artists and bands, creating the perfect summer atmosphere.',
          showDescription: false
        }
      ]
    }
  });