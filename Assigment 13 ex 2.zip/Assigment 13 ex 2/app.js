// app.js
Vue.component('accordion', {
    props: ['items'],
    data() {
      return {
        activeItems: []
      };
    },
    template: `
      <div class="accordion">
        <div v-for="item in items" :key="item.name" class="accordion-item">
          <div class="accordion-header" @click="toggleAccordion(item)">
            <span>{{ item.title }}</span>
            <span v-if="isActive(item)" class="accordion-icon">-</span>
            <span v-else class="accordion-icon">+</span>
          </div>
          <div v-if="isActive(item)" class="accordion-content">
            <slot name="content" :item="item"></slot>
          </div>
        </div>
      </div>
    `,
    methods: {
      toggleAccordion(item) {
        if (this.isActive(item)) {
          this.activeItems = this.activeItems.filter(activeItem => activeItem !== item);
        } else {
          this.activeItems.push(item);
        }
      },
      isActive(item) {
        return this.activeItems.includes(item);
      }
    }
  });
  
  new Vue({
    el: '#app',
    data: {
      accordionItems: [
        { name: 'name1', title: 'Introduction' },
        { name: 'name2', title: 'History of the Company', expanded: true },
        { name: 'name3', title: 'Mission and Vision Statement' },
        { name: 'name4', title: 'Our Team', expanded: true },
        { name: 'name5', title: 'Products and Services' },
        { name: 'name6', title: 'Quality Assurance', expanded: true },
        { name: 'name7', title: 'Client Testimonials' },
        { name: 'name8', title: 'FAQs', expanded: true },
        { name: 'name9', title: 'Career Opportunities' },
        { name: 'name10', title: 'Contact Information', expanded: true},
        { name: 'name11', title: 'Privacy Policy' },
        { name: 'name12', title: 'Terms and Conditions', expanded: true }
      ]
    }
  });